<?php
include ("conn.php");
date_default_timezone_set('Asia/Jakarta');

session_start();

$username = $_POST['username'];
$password = $_POST['password'];
//$password = sha1($password1);


if (empty($username) && empty($password)) {
	header('location:login-staff.php?error1');

} else if (empty($username)) {
	header('location:login-staff.php?error=2');

} else if (empty($password)) {
	header('location:login-staff.php?error=3');

}

$q = mysqli_query($koneksi,"select * from staff where username='$username' AND password='$password'") or die (mysqli_error());
$row = mysqli_fetch_array ($q);

//if (mysqli_num_rows($q) == 1) {
  //  $_SESSION['user_id'] = $row['nik'];
	//$_SESSION['username'] = $row['$username'];
	//$_SESSION['nama'] = $row['nama'];
    //$_SESSION['nik'] = $row['nik'];
    //$_SESSION['gambar'] = $row['gambar'];	

if (mysqli_num_rows($q) == 1) {
    $_SESSION['nik'] = $row['nik'];
	$_SESSION['username'] = $row['username'];
	$_SESSION['nama'] = $row['nama'];
    $_SESSION['gambar'] = $row['gambar'];

	header('location:staff/index.php');
} else {
	header('location:login-staff.php?error=4');
}
?>