-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2018 at 03:26 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stargatedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `fmo`
--

CREATE TABLE `fmo` (
  `no_fmo` varchar(5) NOT NULL,
  `dates` varchar(10) NOT NULL,
  `no_po` varchar(5) NOT NULL,
  `budget_value` varchar(12) NOT NULL,
  `buyer` varchar(25) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `project_name` varchar(150) NOT NULL,
  `division` varchar(100) NOT NULL,
  `pic_user` varchar(30) NOT NULL,
  `pic_ops` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fmo`
--

INSERT INTO `fmo` (`no_fmo`, `dates`, `no_po`, `budget_value`, `buyer`, `phone`, `project_name`, `division`, `pic_user`, `pic_ops`) VALUES
('FM020', '21/05/2018', 'PO020', 'RP 100,000,0', 'RAIHAN', '837365656566', 'PENGADAAN OWNSHOP BANG TCASH', 'ENGINEERING', 'ADLIN', 'LIZA'),
('FM030', '23/05/2018', 'PO030', 'RP444,444,44', 'JULIA', '084784987456', 'PROJECT 3', 'SALES/MARKETING', 'AZHAR', 'FARID'),
('FM07', '25/05/2018', 'PO07', 'RP720,000,00', 'FAIZ', '085878776536', 'PROJECT 7', 'IT SUPPORT', 'MANSUR', 'FATIN'),
('FM121', '01/05/2018', 'PO121', 'RP999,999,99', 'CINDY', '086445478788', 'PROJECT 3', 'SALES MARKETING', 'DIANA', 'FAISAL'),
('FM90', '01/01/2018', 'PO100', 'RP 888,888,8', 'YUNA', '0898989999', 'PENGADAAN TCASH DI SETIAP JAKARTA ', 'IT SUPPORT', 'RINI INDRIANI', 'ZAKI');

-- --------------------------------------------------------

--
-- Table structure for table `notifikasi`
--

CREATE TABLE `notifikasi` (
  `pending` varchar(15) NOT NULL,
  `approved` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pekerjaan`
--

CREATE TABLE `pekerjaan` (
  `no_fmo` varchar(5) NOT NULL,
  `no` int(6) NOT NULL,
  `item_pekerjaan` varchar(50) NOT NULL,
  `quantity` int(6) NOT NULL,
  `unit` varchar(25) NOT NULL,
  `keterangan` varchar(150) NOT NULL,
  `note` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pr`
--

CREATE TABLE `pr` (
  `no_pr` varchar(15) NOT NULL,
  `tanggal_permintaan` varchar(12) NOT NULL,
  `tanggal_delivery` varchar(12) NOT NULL,
  `nama_project` varchar(150) NOT NULL,
  `lokasi` varchar(50) NOT NULL,
  `divisi` varchar(50) NOT NULL,
  `request` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `spm`
--

CREATE TABLE `spm` (
  `no_spm` varchar(15) NOT NULL,
  `tanggal` varchar(15) NOT NULL,
  `uang_harap_dibayar` varchar(12) NOT NULL,
  `kepada` varchar(50) NOT NULL,
  `alamat` varchar(120) NOT NULL,
  `up` varchar(25) NOT NULL,
  `bank` varchar(50) NOT NULL,
  `no_rek` varchar(20) NOT NULL,
  `an` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `spm`
--

INSERT INTO `spm` (`no_spm`, `tanggal`, `uang_harap_dibayar`, `kepada`, `alamat`, `up`, `bank`, `no_rek`, `an`) VALUES
('SP03', '24/05/2018', 'RP890,900,00', 'YANTO', 'FATMAWATI', 'TEST', 'BNI', '98878889000', 'AHMAD'),
('SP06', '24/05/2018', '786,455,334', 'AUFY', 'FATMAWATI', 'TEST', 'MANDIRI', '874646535355', 'FAHRIN'),
('SP08', '24/05/2018', '344,565,344', 'SITY', 'JATINEGARA', 'TEST', 'MANDIRI', '9864620037', 'RAHMAT');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `nik` int(11) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `posisi` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `gambar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`nik`, `nama`, `posisi`, `email`, `phone`, `username`, `password`, `gambar`) VALUES
(880313, 'BOY', 'IT SUPPORT', 'boy@mail.com', '085890598987', 'boy', '9090', 0),
(880808, 'ROY', 'IT SUPPORT', 'roy@mail.com', '085890575648', 'roy', '9090', 123);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(12) NOT NULL,
  `username` varchar(11) NOT NULL,
  `password` int(11) NOT NULL,
  `fullname` varchar(25) NOT NULL,
  `gambar` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `fullname`, `gambar`) VALUES
(1, 'ahmad', 123, 'ahmad bin salem', 'gambar_admin/SMC.jpg'),
(2, 'rini', 123, 'Rini Indriani', 'gambar_admin/SMC.jpg'),
(3, 'vicky', 123, 'vicky vikong', 'gambar_admin/SMC.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fmo`
--
ALTER TABLE `fmo`
  ADD PRIMARY KEY (`no_fmo`);

--
-- Indexes for table `pr`
--
ALTER TABLE `pr`
  ADD PRIMARY KEY (`no_pr`);

--
-- Indexes for table `spm`
--
ALTER TABLE `spm`
  ADD PRIMARY KEY (`no_spm`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`nik`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
