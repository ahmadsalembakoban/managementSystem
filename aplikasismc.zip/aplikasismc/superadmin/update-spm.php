<?php
include "../conn.php";
$no_spm = $_POST['no_spm'];
$tanggal = $_POST['tanggal'];
$uang_harap_dibayar = $_POST['uang_harap_dibayar'];
$kepada = $_POST['kepada'];
$alamat = $_POST['alamat'];
$up = $_POST['up'];
$bank = $_POST['bank'];
$no_rek = $_POST['no_rek'];
$an = $_POST['an'];

$query = mysqli_query($koneksi,"UPDATE spm SET no_spm='$no_spm', tanggal='$tanggal', uang_harap_dibayar='$uang_harap_dibayar' , kepada='$kepada' , alamat='$alamat' , up='$up' , bank='$bank' , no_rek='$no_rek' , an='$an' WHERE no_spm='$no_spm'")or die(mysqli_error());
if ($query){
header('location:spm.php');	
} else {
	echo "gagal";
    }
?>