<?php 
session_start();
if (empty($_SESSION['username'])){
  header('location:../index.php');  
} else {
  include "../conn.php";
?>
<!DOCTYPE html>
<html lang="en">
  <?php include "head.php"; ?>

  <body>

  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <?php include "header.php"; ?>
      <!--header end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
                  <p class="centered"><a href="profile.php?id=<?php echo $_SESSION['user_id']; ?>"><img src="<?php echo $_SESSION['gambar']; ?>" class="img-circle" width="60"></a></p>
                  <h5 class="centered">
              <?php
              echo $_SESSION['fullname'];
               ?></h5>
                    <?php
$timeout = 10; // Set timeout minutes
$logout_redirect_url = "../index.php"; // Set logout URL

$timeout = $timeout * 60; // Converts minutes to seconds
if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
    if ($elapsed_time >= $timeout) {
        session_destroy();
        echo "<script>alert('Session Anda Telah Habis!'); window.location = '$logout_redirect_url'</script>";
    }
}
$_SESSION['start_time'] = time();
?>
<?php } ?>
                    
                  <?php include 'menu.php'; ?>

              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
           
            
            <!-- BASIC FORM ELELEMNTS -->
            <?php
            $query = mysqli_query($koneksi,"SELECT * FROM pr WHERE no_pr='$_GET[kd]'");
            $data  = mysqli_fetch_array($query);
            ?>
            <div class="row mt">
              <div class="col-lg-12">
                  <div class="form-panel">
                      <div class="panel panel-success">
                        <div class="panel-heading">
                        <h4 class="panel-title"><i class="fa fa-book"></i>Edit Data PR </h4> 
                        </div>
                        <div class="panel-body">
                        <div class="table-responsive">
                      <form class="form-horizontal style-form" action="update-pr.php" method="post" name="form1" id="form1">
                          
                              <label class="col-sm-2 col-sm-2 control-label">No PR</label>
                              <div class="col-sm-2">
                                  <input name="no_pr" type="text" id="no_pr" class="form-control" value="<?php echo $data['no_pr'];?>"  readonly="readonly" />
                              </div>

                              <br><br><br>
                          
                          
                              <label class="col-sm-2 col-sm-2 control-label">Tanggal Permintaan</label>
                              <div class="col-sm-2">
                                  <input name="tanggal_permintaan" type="text" id="tanggal_permintaan" class="form-control" value="<?php echo $data['tanggal_permintaan'];?>"autofocus="on" required />
                                  <!--<span class="help-block">A block of help text that breaks onto a new line and may extend beyond one line.</span>-->
                              </div>
                          
                          
                              <label class="col-sm-2 col-sm-2 control-label">Tanggal Delivery</label>
                              <div class="col-sm-2">
                                  <input name="tanggal_delivery" type="text" id="tanggal_delivery" class="form-control" value="<?php echo $data['tanggal_delivery'];?>" required />
                              </div>
                          
                          <br><br><br>
                          
                              <label class="col-sm-2 col-sm-2 control-label">Nama Project</label>
                              <div class="col-sm-6">
                                  <input name="nama_project" type="text" id="nama_project"  class="form-control" value="<?php echo $data['nama_project'];?>" required/>
                              </div>


                        <br><br><br>

                              <label class="col-sm-2 col-sm-2 control-label">Lokasi</label>
                              <div class="col-sm-4">
                                  <input name="lokasi" type="text" id="lokasi" class="form-control" value="<?php echo $data['lokasi'];?>" required  />
                              </div>

                              <br><br><br>
                          
                          
                              <label class="col-sm-2 col-sm-2 control-label">Divisi</label>
                              <div class="col-sm-2">
                                  <input name="divisi" class="form-control" id="divisi" type="text" value="<?php echo $data['divisi'];?>" required />
                              </div>
                          
                          
                              <label class="col-sm-2 col-sm-2 control-label">Request</label>
                              <div class="col-sm-2">
                                  <input name="request" class="form-control" id="request" type="text" value="<?php echo $data['request'];?>" required />  </div>
                          
                          <br><br><br>

                              <label class="col-sm-2 col-sm-2 control-label"></label>
                              <div class="col-sm-10">
                                  <input type="submit" value="Simpan Data"  class="btn btn-sm btn-primary"/>&nbsp;
                                <a href="pr.php" class="btn btn-sm btn-danger">Batal </a>
                              </div>
                          </div>

                      </form>
                  </div>
              </div><!-- col-lg-12-->       
            </div><!-- /row -->
            
            
    </section><! --/wrapper -->
      </section><!-- /MAIN CONTENT -->

      <!--main content end-->
      <!--footer start-->
      <!-- <?php include "footer.php"; ?>  -->
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="assets/js/jquery-ui-1.9.2.custom.min.js"></script>

  <!--custom switch-->
  <script src="assets/js/bootstrap-switch.js"></script>
  
  <!--custom tagsinput-->
  <script src="assets/js/jquery.tagsinput.js"></script>
  
  <!--custom checkbox & radio-->
  
  <script type="text/javascript" src="assets/js/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
  <script type="text/javascript" src="assets/js/bootstrap-daterangepicker/date.js"></script>
  <script type="text/javascript" src="assets/js/bootstrap-daterangepicker/daterangepicker.js"></script>
  
  <script type="text/javascript" src="assets/js/bootstrap-inputmask/bootstrap-inputmask.min.js"></script>
  
  
  <script src="assets/js/form-component.js"></script>    
    
    
  <script>
      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
