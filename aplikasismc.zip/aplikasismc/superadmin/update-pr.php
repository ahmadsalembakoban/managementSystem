<?php
include "../conn.php";
$no_pr = $_POST['no_pr'];
$tanggal_permintaan = $_POST['tanggal_permintaan'];
$tanggal_delivery = $_POST['tanggal_delivery'];
$nama_project = $_POST['nama_project'];
$lokasi = $_POST['lokasi'];
$divisi = $_POST['divisi'];
$request = $_POST['request'];

$query = mysqli_query($koneksi,"UPDATE pr SET no_pr='$no_pr', tanggal_permintaan='$tanggal_permintaan', tanggal_delivery='$tanggal_delivery' , 	nama_project='$nama_project' , lokasi='$lokasi' , divisi='$divisi' , request='$request' WHERE no_pr='$no_pr'")or die(mysqli_error());
if ($query){
header('location:pr.php');	
} else {
	echo "gagal";
    }
?>