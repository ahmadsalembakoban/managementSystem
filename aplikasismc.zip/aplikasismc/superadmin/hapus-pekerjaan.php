<?php
include "../conn.php";
$item_pekerjaan = $_GET['kd'];

$query = mysqli_query($koneksi,"DELETE FROM pekerjaan WHERE item_pekerjaan='$item_pekerjaan'");
if ($query){
	echo "<script>alert('Data Berhasil dihapus!'); window.location = 'pekerjaan.php'</script>";	
} else {
	echo "<script>alert('Data Gagal dihapus!'); window.location = 'pekerjaan.php'</script>";	
}
?>