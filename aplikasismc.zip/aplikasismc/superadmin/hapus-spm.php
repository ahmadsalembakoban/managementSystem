<?php
include "../conn.php";
$no_spm = $_GET['kd'];

$query = mysqli_query($koneksi,"DELETE FROM spm WHERE no_spm='$no_spm'");
if ($query){
	echo "<script>alert('Data Berhasil dihapus!'); window.location = 'spm.php'</script>";	
} else {
	echo "<script>alert('Data Gagal dihapus!'); window.location = 'spm.php'</script>";	
}
?>