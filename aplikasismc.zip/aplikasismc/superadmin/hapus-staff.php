<?php
include "../conn.php";
$nik = $_GET['kd'];

$query = mysqli_query($koneksi,"DELETE FROM staff WHERE nik='$nik'");
if ($query){
	echo "<script>alert('Data Berhasil dihapus!'); window.location = 'staff.php'</script>";	
} else {
	echo "<script>alert('Data Gagal dihapus!'); window.location = 'staff.php'</script>";	
}
?>