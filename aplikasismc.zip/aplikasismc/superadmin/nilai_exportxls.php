<?php
include("../conn.php");
 session_start();
if(empty($_SESSION)){
	header("Location: ../index.php");
}  
?>

 
			<?php
		 			 
// Fungsi header dengan mengirimkan raw data excel
header("Content-type: application/vnd-ms-excel");
 
// Mendefinisikan nama file ekspor "hasil-export.xls"
header("Content-Disposition: attachment; filename=nilai_exportxls.xls");
 
// Tampilkan isi table
			# fungsi ubah tanggal 
						/** function rubah_tanggal($tgl)
						 {
						 $exp = explode('-',$tgl);
						 if(count($exp) == 3)
						 {
						 $tgl = $exp[2].'-'.$exp[1].'-'.$exp[0];
						 }
						 return $tgl;
						 }
			 $plantname = $_GET['toxls'];
			 $date1	= rubah_tanggal($_GET['date1']);
			 $date2	= rubah_tanggal($_GET['date2']);**/
							 
			$sqlshow = mysqli_query($koneksi,"SELECT * FROM fmo ORDER BY no_fmo
																  
												"); 
											//	$sql = mysqli_query($koneksi, "SELECT * FROM t_inventoryitems WHERE f_partcode='$id'");
		
			?>
	  
 
	<h3>Data Form Management Order (FMO)</H>
	 
	<br>  
	<!-- <table>
	
			<tr>
			 <td width="0px">Plant :</td>  <td><?php //echo $plantname ?></td> 
			 <td width="0px">From : <?php //echo date("d-m-Y",strtotime($_GET['date1'])) ?></td>  
			 <td width="0px">Until : <?php //echo date("d-m-Y",strtotime($_GET['date2'])) ?></td> 
			 
		 </tr>
	</table>-->	
    <table>
	
			<tr>
			
			 <td width="0px">Tanggal : <?php echo date("d-m-Y") ?></td>  
			 
			 
		 </tr>
	</table>	
		 
		<table bordered="1">  
			<thead bgcolor="eeeeee" align="center">
			<tr bgcolor="eeeeee" >
	  
			  <th class="text-center">No FMO</th>
			   <th>Tanggal</th>
			   <th>No PO</th>
			   <th class="text-right">Nilai Budget</th>
               <th>Buyer</th>
               <th>No Telp</th>
               <th>Nama Project</th>
               <th>Divisi</th>
               <th>PIC User</th>
               <th>PIC Ops</th>
			  </tr>
			</thead>
			<tbody>
	 	
					
		</tbody>

		</div>
    </div>
</div>
   <?php
						
						//if (isset($_POST['show'])) {
							$rowshow = mysqli_fetch_assoc($sqlshow);
							  
								//$nomor=0;
							while($rowshow = mysqli_fetch_assoc($sqlshow)){					 
                                 //$nomor++;
								echo '<tr>';
								echo '<td>'.$rowshow['no_fmo'].'</td>';
								echo '<td>'.$rowshow['tanggal'].'</td>';
								//echo '<td>'.$rowshow['f_partname'].'/'.$rowshow['f_model'].'/'.$rowshow['f_maker'].'</td>';
                                echo '<td>'.$rowshow['no_po'].'</td>';
                                echo '<td>'.$rowshow['budget_value'].'</td>';
                                echo '<td>'.$rowshow['buyer'].'</td>';
                                echo '<td>'.$rowshow['phone'].'</td>';
								echo '<td>'.$rowshow['project_name'].'</td>';
                                echo '<td>'.$rowshow['division'].'</td>';
                                echo '<td>'.$rowshow['pic_user'].'</td>';
                                echo '<td>'.$rowshow['pic_ops'].'</td>';
                 
								echo '</tr>';
							}
						 
								 
							
					//	}			//EOF IF				
					 ?>
  </table>   
 
   