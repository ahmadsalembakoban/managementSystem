<?php
include "../conn.php";
//$no_fmo      = $_POST['no_fmo'];
$no_spm              = $_POST['no_spm'];
$tanggal             = $_POST['tanggal'];
$uang_harap_dibayar  = $_POST['uang_harap_dibayar'];
$kepada              = $_POST['kepada'];
$alamat              = $_POST['alamat'];
$up                  = $_POST['up'];
$bank                = $_POST['bank'];
$no_rek              = $_POST['no_rek'];
$an                  = $_POST['an'];

/**$sqlCek="SELECT * FROM kelas WHERE nama_kelas='$nama_kelas' AND tahun_ajar='$tahun_ajar'";
	$qryCek=mysql_query($sqlCek) or die ("Eror Query".mysql_error()); 
	if(mysql_num_rows($qryCek)>=1){
		$pesanError[] = "Maaf, Nama Kelas<b> $txtNamaKls </b> dengan <b>tahun ajaran</b> yang sama sudah dibuat";
	} else {}**/
    
$query = mysqli_query($koneksi,"INSERT INTO spm (no_spm, tanggal, uang_harap_dibayar, kepada, alamat, up, bank, no_rek, an) VALUES 
                      ('$no_spm', '$tanggal', '$uang_harap_dibayar', '$kepada', '$alamat', '$up', '$bank', '$no_rek', '$an')");
if ($query){
	echo "<script>alert('Data Berhasil dimasukan!'); window.location = 'spm.php'</script>";	
} else {
	echo "<script>alert('Data Gagal dimasukan!'); window.location = 'spm.php'</script>";	
}

?>