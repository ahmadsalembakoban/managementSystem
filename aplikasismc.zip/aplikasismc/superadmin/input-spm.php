<?php 
session_start();
if (empty($_SESSION['username'])){
	header('location:../index.php');	
} else {
	include "../conn.php";
?>
<!DOCTYPE html>
<html lang="en">
  <?php include "head.php"; ?>
  <body>

  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <?php include "header.php" ?>
      <!--header end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  <p class="centered"><a href="profile.php?id=<?php echo $_SESSION['user_id']; ?>"><img src="<?php echo $_SESSION['gambar']; ?>" class="img-circle" width="60"></a></p>
              	  <h5 class="centered">
              <?php
              echo $_SESSION['fullname'];
               ?></h5>
              	  	<?php
$timeout = 10; // Set timeout minutes
$logout_redirect_url = "../index.php"; // Set logout URL

$timeout = $timeout * 60; // Converts minutes to seconds
if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
    if ($elapsed_time >= $timeout) {
        session_destroy();
        echo "<script>alert('Session Anda Telah Habis!'); window.location = '$logout_redirect_url'</script>";
    }
}
$_SESSION['start_time'] = time();
?>
<?php } ?>
              	  	
                  <?php include 'menu.php'; ?>

              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
          	
          	<!-- BASIC FORM ELELEMNTS -->
          	<div class="row mt">
          		<div class="col-lg-12">
                  <div class="form-panel">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                        <h4 class="panel-title"><i class="fa fa-book"></i> Data SPM </h4> 
                        </div>
                        <div class="panel-body">
                        <div class="table-responsive">

                      <form class="form-horizontal style-form" onsubmit="return formCheck(this);" action="insert-spm.php" method="post" enctype="multipart/form-data" name="form1" id="form1">
                          
                         
                              <label class="col-sm-2 col-sm-2 control-label">No Spm</label>
                              <div class="col-sm-2">
                                  <input name="no_spm" type="text" id="no_spm" class="form-control" placeholder="format:SPXXX" autofocus="on">
                              </div>
                          
                         
                              <label class="col-sm-2 col-sm-2 control-label">Tanggal</label>
                              <div class="col-sm-2">
                                  <input type="text" name="tanggal" id="tanggal" placeholder="format dd/mm/yyyy" class="form-control" required="required" /> 
                              </div>
                          
                             <br><br><br>

                          
                              <label class="col-sm-2 col-sm-2 control-label"> Jumlah Pembayaran</label>
                              <div class="col-sm-2">
                                  <input type="text" size="25" name="uang_harap_dibayar" id="uang_harap_dibayar" placeholder="" class="form-control maxlength="6" required="required" />
                              </div>
                          
                          
                              <label class="col-sm-2 col-sm-2 control-label"> Kepada</label>
                              <div class="col-sm-2">
                                  <input type="text"  size="25" name="kepada" id="kepada" placeholder="" class="form-control" required="required" />
                              </div>
                          
                             <br><br><br>

                              <label class="col-sm-2 col-sm-2 control-label"> Alamat</label>
                              <div class="col-sm-6">
                                  <input type="text" size="25" name="alamat" id="buyer" placeholder="" class="form-control" required="required" />
                              </div>
                          
                             <br><br><br>
                          
                              <label class="col-sm-2 col-sm-2 control-label"> Up</label>
                              <div class="col-sm-2">
                                  <input type="text" size="25" name="up" id="up" placeholder="" class="form-control"  required="required" />
                              </div>
                          
                          
                              <label class="col-sm-2 col-sm-2 control-label">Nama Bank</label>
                              <div class="col-sm-2">
                                  <input type="text" size="25" name="bank" id="bank" placeholder="" class="form-control"  required="required" />
                              </div>
                          
                              <br><br><br>
                                                        
                              <label class="col-sm-2 col-sm-2 control-label"> No Rekening</label>
                              <div class="col-sm-2">
                                  <input type="text" size="25" name="no_rek" id="no_rek" placeholder="" class="form-control" required="required" />
                              </div>
                          
                          
                              <label class="col-sm-2 col-sm-2 control-label"> Atas Nama</label>
                              <div class="col-sm-2">
                                  <input type="text" size="25" name="an" id="an" placeholder="" class="form-control" required="required" />
                              </div>
                              
                              <br><br><br>
                       

                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label"></label>
                              <div class="col-sm-10">
                                  <input type="submit" value="Simpan" class="btn btn-sm btn-primary" />&nbsp;
	                              <a href="spm.php" class="btn btn-sm btn-danger">Batal </a>
                              </div>
                          </div>
                      </form>
                  </div>
          		</div><!-- col-lg-12-->      	
          	</div><!-- /row -->
          	
          	
		</section><! --/wrapper -->
      </section><!-- /MAIN CONTENT -->

      <!--main content end-->
      <!--footer start-->
      <!-- <?php include "footer.php"; ?>  -->
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="assets/js/jquery-ui-1.9.2.custom.min.js"></script>

	<!--custom switch-->
	<script src="assets/js/bootstrap-switch.js"></script>
	
	<!--custom tagsinput-->
	<script src="assets/js/jquery.tagsinput.js"></script>
	
	<!--custom checkbox & radio-->
	
	<script type="text/javascript" src="assets/js/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap-daterangepicker/date.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap-daterangepicker/daterangepicker.js"></script>
	
	<script type="text/javascript" src="assets/js/bootstrap-inputmask/bootstrap-inputmask.min.js"></script>
	
	
	<script src="assets/js/form-component.js"></script>    
    <script src="assets/js/jquery.validate.js"></script>    
    <script>
    $(document).ready(function(){
        $("#form1").validate();
    });
    </script> 
    
    <style type="text/css">
    label.error {
        color: red;
        padding-left: .5em;
    }
    </style>
    
    
  <script>
      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>
  <script type="text/javascript" src="assets/tiny_mce/tiny_mce.js"></script>
	<script type="text/javascript">
	tinyMCE.init({
	mode : "exact",
	elements : "elm2",
	theme : "advanced",
	skin : "o2k7",
	skin_variant : "silver",
	plugins : "safari,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,inlinepopups",
	
	theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,styleselect,formatselect,fontselect,fontsizeselect",
	theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,|,insertdate,inserttime,preview,|,forecolor,backcolor",
	theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
	theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak",
	theme_advanced_toolbar_location : "top",
	theme_advanced_toolbar_align : "left",
	theme_advanced_statusbar_location : "bottom",
	theme_advanced_resizing : true,
	
	template_external_list_url : "lists/template_list.js",
	external_link_list_url : "lists/link_list.js",
	external_image_list_url : "lists/image_list.js",
	media_external_list_url : "lists/media_list.js",
	
	template_replace_values : {
		username : "Some User",
		staffid : "991234"
	}
	});
	</script>

  </body>
</html>
