                  <li class="mt">
                      <a class="active" href="index.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Halaman Utama</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-book"></i>
                          <span>Form Management Order (FMO)</span>
                      </a>
                          <ul class="sub">
                          <li><a  href="fmo.php">FMO</a></li>
                         </ul>
                </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-book"></i>
                          <span>Surat Perintah Membayar (SPM)</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="spm.php">SPM</a></li>
                      </ul>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-book"></i>
                          <span>Purchase Request (PR)</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="pr.php">PR</a></li>
                      </ul>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-user"></i>
                          <span>Karyawan</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="staff.php">Data Karyawan</a></li>
                          <li><a  href="input-staff.php">Tambah Karyawan</a></li>
                          <!--<li><a  href="calendar.html">Kalender</a></li>-->
                      </ul>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-user"></i>
                          <span>Admin</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="admin.php">Data Admin</a></li>
                          <li><a  href="input-admin.php">Tambah Admin</a></li>
                          <!--<li><a  href="calendar.html">Kalender</a></li>-->
                      </ul>
                  </li>

                  
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class=" fa fa-edit"></i>
                          <span>Laporan</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="fmo_pdf.php">Sales Report</a></li>
                          <li><a  href="spm_pdf.php">Laporan SPM</a></li>
                          <li><a  href="pr_pdf.php">Laporan PR</a></li>
                          <!--<li><a href="fmo_detail_report.php">Report FMO</a></li> -->
                          <li><a href="nilai.php">Data Excel</a></li>
                      </ul>
                  </li>
