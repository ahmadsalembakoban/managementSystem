<footer class="site-footer">
          <div class="text-center">
              <a>SMC Group</a> &copy; 2018
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>