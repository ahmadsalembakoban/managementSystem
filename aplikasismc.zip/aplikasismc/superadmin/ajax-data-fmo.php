<?php
/* Database connection start */
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "stargatedb";

$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());

/* Database connection end */


// storing  request (ie, get/post) global array to a variable  
$requestData= $_REQUEST;


$columns = array( 
// datatable column index  => database column name
	
	0 => 'no_fmo',
    1 => 'tanggal', 
	2 => 'nilai_budget',
    3 => 'buyer',
    4 => 'phone',
    5 => 'nama_project',
    6 => 'divisi',
    7 => 'pic_user',
    8 => 'pic_ops',
    9 => 'item_pekerjaan',
    10 => 'jenis_pekerjaan',
    11 => 'tanggal_pekerjaan',
    12 => 'quantity',
    13 => 'unit',
    14 => 'frek',
    15 => 'keterangan',
    16 => 'no_po'
    
);

// getting total number records without any search
$sql = "SELECT no_fmo, tanggal, nilai_budget, budget_value,buyer,phone,project_name,division,pic_user,pic_ops";
$sql.=" FROM fmo";
$query=mysqli_query($conn, $sql) or die("ajax-data-fmo.php: get Fmo");
$totalData = mysqli_num_rows($query);
$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.


if( !empty($requestData['search']['value']) ) {
	// if there is a search parameter
	/** $sql = "SELECT no_fmo, dates, no_po, budget_value,buyer,phone,project_name,division,pic_user,pic_ops"; **/
	$sql = "SELECT no_fmo, dates, no_po, budget_value, buyer, phone, project_name, division, pic_user, pic_ops";
	$sql.=" FROM fmo";
	$sql.=" WHERE no_fmo LIKE '".$requestData['search']['value']."%' ";    // $requestData['search']['value'] contains search parameter
	$sql.=" OR dates LIKE '".$requestData['search']['value']."%' ";
    $sql.=" OR no_po LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR budget_value LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR buyer LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR phone LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR project_name LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR division LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR pic_user LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR pic_ops LIKE '".$requestData['search']['value']."%' ";
	$query=mysqli_query($conn, $sql) or die("ajax-data.php: get Fmo");
	$totalFiltered = mysqli_num_rows($query); // when there is a search parameter then we have to modify total number filtered rows as per search result without limit in the query 

	$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."   LIMIT ".$requestData['start']." ,".$requestData['length']."   "; // $requestData['order'][0]['column'] contains colmun index, $requestData['order'][0]['dir'] contains order such as asc/desc , $requestData['start'] contains start row number ,$requestData['length'] contains limit length.
	$query=mysqli_query($conn, $sql) or die("ajax-data-fmo.php: get Fmo"); // again run query with limit
	
} else {	

	$sql = "SELECT no_fmo, dates, no_po, budget_value, buyer, phone, project_name, division, pic_user, pic_ops";
	$sql.=" FROM fmo";
	$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."   LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
	$query=mysqli_query($conn, $sql) or die("ajax-data-fmo.php: get Fmo");   
	
}

$data = array();
while( $row=mysqli_fetch_array($query) ) {  // preparing an array
	$nestedData=array(); 
    
	$nestedData[] = $row["no_fmo"];
    $nestedData[] = $row["dates"];
    $nestedData[] = $row["no_po"];
	$nestedData[] = $row["budget_value"];
	$nestedData[] = $row["buyer"];
	$nestedData[] = $row["phone"];
	$nestedData[] = $row["project_name"];
	$nestedData[] = $row["division"];
	$nestedData[] = $row["pic_user"];
	$nestedData[] = $row["pic_ops"];
    $nestedData[] = '<td><center>
                     <a href="edit-fmo.php?kd='.$row['no_fmo'].'"  data-toggle="tooltip" title="Edit" class="btn btn-sm btn-primary"> <i class="glyphicon glyphicon-edit"></i> </a>
				     <a href="hapus-fmo.php?kd='.$row['no_fmo'].'"  data-toggle="tooltip" title="Delete" onclick="return confirm(\'Anda yakin akan menghapus data '.$row['dates'].'?\')" class="btn btn-sm btn-danger"> <i class="glyphicon glyphicon-trash"> </i> </a>
	                 </center></td>';		
	
	$data[] = $nestedData;
    
}



$json_data = array(
			"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
			"recordsTotal"    => intval( $totalData ),  // total number of records
			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
			"data"            => $data   // total data array
			);

echo json_encode($json_data);  // send data as json format

?>
