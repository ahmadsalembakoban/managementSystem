<?php
session_start();
if (empty($_SESSION['username'])){
    header('location:../index.php');    
} else {
    include "../conn.php";
require('../fpdf17/fpdf.php');
require('../conn.php');


//Select the Products you want to show in your PDF file
//$result=mysql_query("SELECT * FROM daily_bbri where date like '%$periode%' ");



$result=mysqli_query($koneksi,"SELECT * FROM fmo ORDER BY no_fmo ASC") or die(mysqli_error());
$result2=mysqli_query($koneksi,"SELECT * FROM pekerjaan ORDER BY no_fmo ASC") or die (mysqli_error());

//Initialize the 3 columns and the total
$column_no_fmo = "";
$column_dates = "";
$column_no_po = "";
$column_nilai_budget = "";
$column_buyer = "";
$column_phone = "";
$column_nama_project = "";
$column_division = "";
$column_pic_user = "";
$column_pic_ops = "";


$column_no_fmo="";
$column_no="";
$column_quantity="";
$column_unit="";
$column_keterangan="";
$column_note="";

$no=0;
//For each row, add the field to the corresponding column
while($row = mysqli_fetch_array($result))
{
    $no=0;

    $no_fmo = $row["no_fmo"];
    $dates = $row["dates"];
    $no_po = $row["no_po"];
    $budget_value = $row["budget_value"];
    $buyer = $row["buyer"];
    $phone = $row["phone"];
    $project_name = $row["project_name"];
    $division = $row["division"];
    $pic_user = $row["pic_user"];
    $pic_ops = $row["pic_ops"];

    $column_no_fmo=$column_no_fmo.$no_fmo."\n";
    $column_dates=$column_dates.$dates."\n";
    $column_no_po=$column_no_po.$no_po."\n";
    $column_nilai_budget=$column_nilai_budget.$budget_value."\n";
    $column_buyer=$column_buyer.$buyer."\n";
    $column_phone=$column_phone.$phone."\n";
    $column_nama_project=$column_nama_project.$project_name."\n";
    $column_division=$column_division.$division."\n";
    $column_pic_user=$column_pic_user.$pic_user."\n";
    $column_pic_ops=$column_pic_ops.$pic_ops."\n";
    
            
//mysql_close();

$pdf = new FPDF('L','mm',array(350,210)); //L For Landscape / P For Portrait
$pdf->AddPage();

//$pdf->Image('../foto/logo.png',10,10,-175);
//$pdf->Image('../images/BBRI.png',190,10,-200);
$pdf->SetFont('Arial','B',13);
$pdf->Cell(150);
$pdf->Cell(30,10,'FORM MANAGEMENT ORDER (FMO)',0,0,'C');
$pdf->Ln();
$pdf->Cell(150);
$pdf->Cell(30,10,'SMC GROUP',0,0,'C');
$pdf->Ln();

}
//Fields Name position
$Y_Fields_Name_position = 52;

//First create each Field Name
//Gray color filling each Field Name box
//$pdf->SetFillColor(110,180,230);
//Bold Font for Field Name
$pdf->SetFont('Arial','B',12);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(70);
$pdf->Cell(20,8,'No Fmo         : '.$no_fmo,0,0,'L',0);
$pdf->SetX(200);
$pdf->Cell(25,8,'Nama Project : '.$project_name,0,0,'L',0);
$pdf->Ln();

$pdf->SetX(70);
$pdf->Cell(20,8,'Tanggal         : '.$dates,0,0,'L',0);
$pdf->SetX(200);
$pdf->Cell(25,8,'Nama User     : '.$pic_user,0,0,'L',0);
$pdf->Ln();

$pdf->SetX(70);
$pdf->Cell(20,8,'No Po             : '.$no_po,0,0,'L',0);
$pdf->SetX(200);
$pdf->Cell(25,8,'No Telp           : '.$phone,0,0,'L',0);
$pdf->Ln();

$pdf->SetX(70);
$pdf->Cell(20,8,'Nilai Budget  : '.$budget_value,0,0,'L',0);
$pdf->SetX(200);
$pdf->Cell(25,8,'Divisi              : '.$division,0,0,'L',0);
$pdf->Ln();

$pdf->SetX(70);
$pdf->Cell(20,8,'Buyer             : '.$buyer,0,0,'L',0);
$pdf->SetX(200);
$pdf->Cell(25,8,'PIC Ops          : '.$pic_ops,0,0,'L',0);
$pdf->Ln();




$no=0;

    $no_fmo = $row["no_fmo"];
    $nom = $row["nom"];
    $nitem_pekerjaan = $row["item_pekerjaan"];
    $budget_quantity = $row["quantity"];
    $unit = $row["unit"];
    $keterangan = $row["keterangan"];
    $note = $row["note"];
    
    $column_no_fmo=$column_no_fmo.$no_fmo."\n";
    $column_no=$column_nom.$nom."\n";
    $column_item_pekerjan=$column_item_pekerjaan.$item_pekerjaan."\n";
    $column_quantity=$column_quantity.$quantity."\n";
    $column_unit=$unit.$unit."\n";
    $column_keterangan=$column_keterangan.$keterangan."\n";
    $column_note=$column_note.$note."\n";
    

    //table form

$Y_Fields_Name_position = 100;

//First create each Field Name
//Gray color filling each Field Name box
$pdf->SetFillColor(110,180,230);
//Bold Font for Field Name
$pdf->SetFont('Arial','B',10);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(20);
$pdf->Cell(20,8,'No Fmo',1,0,'C',1);
$pdf->SetX(40);
$pdf->Cell(25,8,'Tanggal',1,0,'C',1);
$pdf->SetX(65);
$pdf->Cell(80,8,'Nama Event',1,0,'C',1);
$pdf->SetX(145);
$pdf->Cell(35,8,'User',1,0,'C',1);
$pdf->SetX(180);
$pdf->Cell(25,8,'No Po',1,0,'C',1);
$pdf->SetX(205);
$pdf->Cell(27,8,'Nilai Po',1,0,'C',1);
$pdf->SetX(232);
$pdf->Cell(27,8,'Buyer',1,0,'C',1);
$pdf->SetX(259);
$pdf->Cell(27,8,'No Bast',1,0,'C',1);
$pdf->SetX(286);
$pdf->Cell(25,8,'Tanggal Bast',1,0,'C',1);
$pdf->SetX(311);
$pdf->Cell(28,8,'Nilai Bast',1,0,'C',1);
$pdf->Ln();

//Table position, under Fields Name
 $Y_Table_Position = 108;

//Now show the columns
$pdf->SetFont('Arial','',10);

$pdf->SetY($Y_Table_Position);
$pdf->SetX(20);
$pdf->MultiCell(20,6,$column_no_fmo,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(40);
$pdf->MultiCell(25,6,$column_dates,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(65);
$pdf->MultiCell(80,6,$column_nama_project,1,'L');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(145);
$pdf->MultiCell(35,6,$column_pic_user,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(180);
$pdf->MultiCell(25,6,$column_no_po,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(205);
$pdf->MultiCell(27,6,$column_nilai_budget,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(232);
$pdf->MultiCell(27,6,$column_buyer,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(259);
$pdf->MultiCell(27,6,$column_phone,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(286);
$pdf->MultiCell(25,6,$column_dates,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(311);
$pdf->MultiCell(28,6,$column_nilai_budget,1,'C');


$pdf->Output();

//$pdf->SetX(50);
//$pdf->Cell(80,8,'Nama Event',1,0,'C',1);
//$pdf->SetX(130);
//$pdf->Cell(35,8,'User',1,0,'C',1);
//$pdf->SetX(165);
//$pdf->Cell(25,8,'No Po',1,0,'C',1);
//$pdf->SetX(190);
//$pdf->Cell(27,8,'Nilai Po',1,0,'C',1);
//$pdf->SetX(217);
//$pdf->Cell(27,8,'Buyer',1,0,'C',1);
//$pdf->SetX(244);
//$pdf->Cell(27,8,'No Bast',1,0,'C',1);
//$pdf->SetX(271);
//$pdf->Cell(25,8,'Tanggal Bast',1,0,'C',1);
//$pdf->SetX(296);
//$pdf->Cell(28,8,'Nilai Bast',1,0,'C',1);
//$pdf->Ln();

//Table position, under Fields Name
 //$Y_Table_Position = 38;

//Now show the columns
//$pdf->SetFont('Arial','',10);

//$pdf->SetY($Y_Table_Position);
//$pdf->SetX(18);
//$pdf->MultiCell(20,6,$column_no_fmo,0,'C');

//$pdf->SetY($Y_Table_Position);
//$pdf->SetX(25);
//$pdf->MultiCell(25,6,$column_dates,1,'C');

//$pdf->SetY($Y_Table_Position);
//$pdf->SetX(50);
//$pdf->MultiCell(80,6,$column_nama_project,1,'L');

//$pdf->SetY($Y_Table_Position);
//$pdf->SetX(130);
//$pdf->MultiCell(35,6,$column_pic_user,1,'C');

//$pdf->SetY($Y_Table_Position);
//$pdf->SetX(165);
//$pdf->MultiCell(25,6,$column_no_po,1,'C');

//$pdf->SetY($Y_Table_Position);
//$pdf->SetX(190);
//$pdf->MultiCell(27,6,$column_nilai_budget,1,'C');

//$pdf->SetY($Y_Table_Position);
//$pdf->SetX(217);
//$pdf->MultiCell(27,6,$column_buyer,1,'C');

//$pdf->SetY($Y_Table_Position);
//$pdf->SetX(244);
//$pdf->MultiCell(27,6,$column_phone,1,'C');

//$pdf->SetY($Y_Table_Position);
//$pdf->SetX(271);
//$pdf->MultiCell(25,6,$column_dates,1,'C');

//$pdf->SetY($Y_Table_Position);
//$pdf->SetX(296);
//$pdf->MultiCell(28,6,$column_nilai_budget,1,'C');



//Footer Table 
/**$pdf->SetFillColor(110,180,230);
$pdf->SetFont('Arial','B',12);
$pdf->SetX(5);
$pdf->Cell(40,8,'Keterangan',1,0,'C',1);
$pdf->SetX(45);
$pdf->Cell(160,8,$ket.'',1,0,'R',1);
$pdf->Ln();
$pdf->SetFillColor(110,180,230);
$pdf->Ln(10);
**/
//After Footer

/**$Y_Fields_Name_position = 150;
$pdf->SetFillColor(255,255,255);
//First create each Field Name
//Bold Font for Field Name
$pdf->SetFont('Arial','B',10);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(15);
$pdf->Cell(40,8,'Kepala Sekolah,',0,0,'L',1);
$pdf->SetX(160);
$pdf->Cell(40,8,'',0,0,'L',1);
$pdf->SetX(85);
$pdf->Cell(50,8,'',0,0,'C',1);
$pdf->SetX(135);
$pdf->Cell(25,8,'',0,0,'C',1);
$pdf->SetX(160);
//$pdf->Cell(45,8,'Order : '.$tgl,0,0,'R',1);
$pdf->Ln();

$Y_Fields_Name_position = 170;
$pdf->SetFillColor(255,255,255);
//First create each Field Name
//Bold Font for Field Name
$pdf->SetFont('Arial','B',10);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(5);
$pdf->Cell(40,8,'Hakko Bio Richard, Amd.Kom',0,0,'L',1);
$pdf->SetX(160);
$pdf->Cell(40,8,'',0,0,'L',1);
$pdf->SetX(85);
$pdf->Cell(50,8,'',0,0,'C',1);
$pdf->SetX(135);
$pdf->Cell(25,8,'',0,0,'C',1);
$pdf->SetX(160);
//$pdf->Cell(45,8,'Order : '.$tgl,0,0,'R',1);
$pdf->Ln();**/

/**$pdf->SetY(-55);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(10);
$pdf->Cell(30,10,'PT. BBG',0,0,'C');
$pdf->Cell(105);
$pdf->Cell(30,10,'PT. BBRI',0,0,'C');
$pdf->Ln(20);
$pdf->Cell(10);
$pdf->Cell(30,10,'( ............................................................)',0,0,'C');
$pdf->Cell(107);
$pdf->Cell(30,10,'( ............................................................)',0,0,'C');
**/
$pdf->Output();
}


while($row = mysqli_fetch_array($result2))
{
    $no=0;

    $no_fmo = $row["no_fmo"];
    $no = $row["no"];
    $nitem_pekerjaan = $row["item_pekerjaan"];
    $budget_quantity = $row["quantity"];
    $unit = $row["unit"];
    $keterangan = $row["keterangan"];
    $note = $row["note"];
    
    $column_no_fmo=$column_no_fmo.$no_fmo."\n";
    $column_no=$column_no.$no."\n";
    $column_item_pekerjan=$column_item_pekerjaan.$item_pekerjaan."\n";
    $column_quantity=$column_quantity.$quantity."\n";
    $column_unit=$unit.$unit."\n";
    $column_keterangan=$column_keterangan.$keterangan."\n";
    $column_note=$column_note.$note."\n";
    

    //table form

$Y_Fields_Name_position = 100;

//First create each Field Name
//Gray color filling each Field Name box
$pdf->SetFillColor(110,180,230);
//Bold Font for Field Name
$pdf->SetFont('Arial','B',10);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(20);
$pdf->Cell(20,8,'No Fmo',1,0,'C',1);
$pdf->SetX(40);
$pdf->Cell(25,8,'Tanggal',1,0,'C',1);
$pdf->SetX(65);
$pdf->Cell(80,8,'Nama Event',1,0,'C',1);
$pdf->SetX(145);
$pdf->Cell(35,8,'User',1,0,'C',1);
$pdf->SetX(180);
$pdf->Cell(25,8,'No Po',1,0,'C',1);
$pdf->SetX(205);
$pdf->Cell(27,8,'Nilai Po',1,0,'C',1);
$pdf->SetX(232);
$pdf->Cell(27,8,'Buyer',1,0,'C',1);
$pdf->SetX(259);
$pdf->Cell(27,8,'No Bast',1,0,'C',1);
$pdf->SetX(286);
$pdf->Cell(25,8,'Tanggal Bast',1,0,'C',1);
$pdf->SetX(311);
$pdf->Cell(28,8,'Nilai Bast',1,0,'C',1);
$pdf->Ln();

//Table position, under Fields Name
 $Y_Table_Position = 108;

//Now show the columns
$pdf->SetFont('Arial','',10);

$pdf->SetY($Y_Table_Position);
$pdf->SetX(20);
$pdf->MultiCell(20,6,$column_no_fmo,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(40);
$pdf->MultiCell(25,6,$column_dates,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(65);
$pdf->MultiCell(80,6,$column_nama_project,1,'L');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(145);
$pdf->MultiCell(35,6,$column_pic_user,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(180);
$pdf->MultiCell(25,6,$column_no_po,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(205);
$pdf->MultiCell(27,6,$column_nilai_budget,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(232);
$pdf->MultiCell(27,6,$column_buyer,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(259);
$pdf->MultiCell(27,6,$column_phone,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(286);
$pdf->MultiCell(25,6,$column_dates,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(311);
$pdf->MultiCell(28,6,$column_nilai_budget,1,'C');


$pdf->Output();
}
?>
