<?php
include "../conn.php";
//$no_fmo      = $_POST['no_fmo'];
$no_fmo = $_POST['no_fmo'];
$dates      = $_POST['dates'];
$no_po     = $_POST['no_po'];
$budget_value     = $_POST['budget_value'];
$buyer   = $_POST['buyer'];
$phone   = $_POST['phone'];
$project_name   = $_POST['project_name'];
$division   = $_POST['division'];
$pic_user   = $_POST['pic_user'];
$pic_ops   = $_POST['pic_ops'];

/**$sqlCek="SELECT * FROM kelas WHERE nama_kelas='$nama_kelas' AND tahun_ajar='$tahun_ajar'";
	$qryCek=mysql_query($sqlCek) or die ("Eror Query".mysql_error()); 
	if(mysql_num_rows($qryCek)>=1){
		$pesanError[] = "Maaf, Nama Kelas<b> $txtNamaKls </b> dengan <b>tahun ajaran</b> yang sama sudah dibuat";
	} else {}**/
    
$query = mysqli_query($koneksi,"INSERT INTO fmo (no_fmo, dates, no_po, budget_value, buyer, phone, project_name, division, pic_user, pic_ops) VALUES 
                      ('$no_fmo', '$dates', '$no_po', '$budget_value', '$buyer', '$phone', '$project_name', '$division', '$pic_user', '$pic_ops')");
if ($query){
	echo "<script>alert('Data Berhasil dimasukan!'); window.location = 'fmo.php'</script>";	
} else {
	echo "<script>alert('Data Gagal dimasukan!'); window.location = 'fmo.php'</script>";	
}

?>